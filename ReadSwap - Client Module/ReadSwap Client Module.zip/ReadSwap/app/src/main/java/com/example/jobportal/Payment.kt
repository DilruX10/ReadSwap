package com.example.ReadSwap

data class Payment(
    val id: String = "",
    val bookId: String = "",
    val bookTitle: String = "",
    val bookBudget: Double = 0.0,
    val count: Int = 0,
    val amountPaid: Double = 0.0
)