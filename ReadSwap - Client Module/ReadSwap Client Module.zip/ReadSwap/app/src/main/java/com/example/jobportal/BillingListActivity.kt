package com.example.ReadSwap

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.database.*
import kotlinx.coroutines.launch

class BillingListActivity : ViewModel() {

    private val _payments = MutableLiveData<List<Payment>>()
    val payments: LiveData<List<Payment>> = _payments

    private val databaseReference: DatabaseReference = FirebaseDatabase.getInstance("https://readswap-9710a-default-rtdb.firebaseio.com/").getReference("payments")

    init {
        fetchPayments()
    }

    private fun fetchPayments() {
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val paymentsList = mutableListOf<Payment>()
                for (paymentSnapshot in snapshot.children) {
                    if (paymentSnapshot.value is HashMap<*, *>) {
                        val paymentMap = paymentSnapshot.value as HashMap<*, *>
                        val payment = Payment(
                            paymentSnapshot.key.toString(),
                            paymentMap["bookId"].toString(),
                            paymentMap["bookTitle"].toString(),
                            (paymentMap["bookBudget"] as Number).toDouble(),
                            (paymentMap["count"] as Number).toInt(),
                            (paymentMap["amountPaid"] as Number).toDouble()
                        )
                        paymentsList.add(payment)
                    }
                }
                _payments.value = paymentsList
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun addPayment(payment: Payment) {
        databaseReference.push().setValue(payment)
    }

    fun updatePayment(payment: Payment) = viewModelScope.launch {
        databaseReference.child(payment.id).setValue(payment)
    }

    fun deletePayment(payment: Payment) = viewModelScope.launch {
        databaseReference.child(payment.id).removeValue()
    }

    fun getAllPayments(): LiveData<List<Payment>> {
        return payments
    }
}
