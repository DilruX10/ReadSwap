package com.example.ReadSwap

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class PaymentAdapter : BaseAdapter() {
    private var paymentList: List<Payment> = emptyList()

    override fun getCount(): Int {
        return paymentList.size
    }

    override fun getItem(position: Int): Any {
        return paymentList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view = convertView
        val holder: ViewHolder

        if (view == null) {
            view = LayoutInflater.from(parent?.context).inflate(R.layout.payment_item, parent, false)
            holder = ViewHolder(view)
            view.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }

        val payment = paymentList[position]
        holder.bookTitleTextView.text = payment.bookTitle
        holder.bookBudgetTextView.text = parent?.context?.getString(R.string.budget_format, payment.bookBudget)
        holder.countTextView.text = payment.count.toString()
        holder.amountPaidTextView.text = parent?.context?.getString(R.string.budget_format, payment.amountPaid)

        return view!!
    }

    class ViewHolder(view: View) {
        val bookTitleTextView: TextView = view.findViewById(R.id.book_title_text_view)
        val bookBudgetTextView: TextView = view.findViewById(R.id.book_budget_text_view)
        val countTextView: TextView = view.findViewById(R.id.count_text_view)
        val amountPaidTextView: TextView = view.findViewById(R.id.amount_paid_text_view)
    }

    fun setPaymentList(paymentList: List<Payment>) {
        this.paymentList = paymentList
        notifyDataSetChanged()
    }
}

