package com.example.ReadSwap

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class PaymentActivity : AppCompatActivity() {

    companion object {
        const val BOOK_EXTRA = "book_extra"
    }

    private lateinit var book: Book

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        // Retrieve the Book object from the intent extra
        book = intent.getSerializableExtra(BOOK_EXTRA) as? Book ?: run {
            Toast.makeText(this, "Invalid book data", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Set the book title and budget values in the views
        val titleTextView: TextView = findViewById(R.id.title_text_view)
        val budgetTextView: TextView = findViewById(R.id.book_budget_value_text_view)
        titleTextView.text = book.title
        budgetTextView.text = getString(R.string.budget_format, book.budget)

        // Set up the payment input fields and button
        val countEditText: EditText = findViewById(R.id.count_edit_text)
        val payButton: Button = findViewById(R.id.pay_button)
        payButton.setOnClickListener {
            val count = countEditText.text.toString().toIntOrNull()
            if (count != null && count > 0) {
                // Make the payment and update the Firebase database
                val updatedBook = book.copy(budget = book.budget - count)
                FirebaseDatabase.getInstance("https://example-job-portal.firebaseio.com/")
                    .getReference("books")
                    .child(updatedBook.id)
                    .setValue(updatedBook)

                // Show a success message and finish the activity
                Toast.makeText(this, "Payment successful", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                // Show an error message for an invalid count value
                countEditText.error = "Enter a valid count"
            }
        }
    }
}

