package com.example.ReadSwap

data class Book(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    var budget: Double = 0.0,
    val contactNumber: String = "",
    val location: String = ""
)
