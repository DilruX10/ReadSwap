package com.example.ReadSwap

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PaymentDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_details)

        val payment = intent.getParcelableExtra<Payment>("payment")

        val bookTitleTextView = findViewById<TextView>(R.id.book_title_text_view)
        val bookBudgetTextView = findViewById<TextView>(R.id.book_budget_text_view)
        val countTextView = findViewById<TextView>(R.id.count_text_view)
        val amountPaidTextView = findViewById<TextView>(R.id.amount_paid_text_view)

        payment?.let {
            bookTitleTextView.text = it.bookTitle ?: ""
            bookBudgetTextView.text = getString(R.string.budget_format, it.bookBudget ?: 0.0)
            countTextView.text = it.count.toString()
            amountPaidTextView.text = getString(R.string.budget_format, it.amountPaid ?: 0.0)
        } ?: run {
            // Handle the case where payment is null
            bookTitleTextView.text = ""
            bookBudgetTextView.text = ""
            countTextView.text = ""
            amountPaidTextView.text = ""
        }

    }
}
