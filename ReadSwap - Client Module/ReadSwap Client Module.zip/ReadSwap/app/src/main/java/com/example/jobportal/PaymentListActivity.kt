package com.example.ReadSwap

import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class PaymentListActivity : AppCompatActivity() {
    private lateinit var paymentListView: ListView
    private lateinit var paymentAdapter: PaymentAdapter
    private var paymentList: List<Payment> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_list)

        paymentListView = findViewById(R.id.payment_list_view)
        paymentAdapter = PaymentAdapter()
        paymentListView.adapter = paymentAdapter

        // Retrieve payment information from Firebase
        val databaseReference: DatabaseReference = FirebaseDatabase.getInstance("https://readswap-9710a-default-rtdb.firebaseio.com/").getReference("payments")
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val tempList = mutableListOf<Payment>()

                for (paymentSnapshot in snapshot.children) {
                    val payment = paymentSnapshot.getValue(Payment::class.java)
                    payment?.let {
                        tempList.add(it)
                    }
                }

                paymentList = tempList
                paymentAdapter.setPaymentList(paymentList)
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }
}

