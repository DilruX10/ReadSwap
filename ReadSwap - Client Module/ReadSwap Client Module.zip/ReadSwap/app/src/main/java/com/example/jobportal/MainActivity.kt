package com.example.ReadSwap

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.FirebaseDatabase


class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: JobsViewModel
    private lateinit var jobAdapter: JobAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this).get(JobsViewModel::class.java)

        jobAdapter = JobAdapter(
            onEditClick = { job -> editJob(job) },
            onDeleteClick = { job -> viewModel.deleteJob(job) },
            onPayClick = { job -> showPaymentDialog(job) },
            showPaymentButton = true
        )

        val recyclerView: RecyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = jobAdapter

        viewModel.books.observe(this, Observer<List<Book>> { books ->
            jobAdapter.setJobs(books)
        })

        val addJobButton: Button = findViewById(R.id.fab_add_job)
        addJobButton.setOnClickListener { showAddEditJobDialog() }

        val payButton: Button = findViewById(R.id.pay_button)
        payButton.setOnClickListener { openPaymentPage() }
    }

    private fun openPaymentPage() {
        val intent = Intent(this, BillingListActivity::class.java)
        startActivity(intent)
    }

    private fun editJob(job: Book) {
        showAddEditJobDialog(job)
    }

    private fun showPaymentDialog(job: Book) {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.payment_dialog, null)
        val titleTextView = view.findViewById<TextView>(R.id.payment_title)
        val budgetTextView = view.findViewById<TextView>(R.id.payment_budget)
        val countEditText = view.findViewById<EditText>(R.id.payment_count)
        val payButton = view.findViewById<Button>(R.id.payment_pay_button)
        val cancelButton = view.findViewById<Button>(R.id.payment_cancel_button)

        titleTextView.text = job.title
        budgetTextView.text = getString(R.string.budget_format, job.budget)

        val builder = AlertDialog.Builder(this)
        builder.setView(view)
        val dialog = builder.create()

        payButton.setOnClickListener {
            val count = countEditText.text.toString().toIntOrNull() ?: 0
            if (count > 0) {
                val payment = Payment(
                    bookId = job.id,
                    bookTitle = job.title,
                    bookBudget = job.budget,
                    count = count,
                    amountPaid = job.budget * count
                )
                addPayment(payment)
                dialog.dismiss()
            } else {
                Toast.makeText(this, R.string.invalid_count, Toast.LENGTH_SHORT).show()
            }
        }

        cancelButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun addPayment(payment: Payment) {
        FirebaseDatabase.getInstance("https://readswap-9710a-default-rtdb.firebaseio.com/")
            .getReference("payments")
            .push()
            .setValue(payment)
    }

    private fun showAddEditJobDialog(jobToEdit: Book? = null) {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.add_job_dialog, null)

        val titleEditText = view.findViewById<EditText>(R.id.title_edit_text)
        val descriptionEditText = view.findViewById<EditText>(R.id.description_edit_text)
        val budgetEditText = view.findViewById<EditText>(R.id.budget_edit_text)
        val contactNumberEditText = view.findViewById<EditText>(R.id.contact_number_edit_text)
        val locationEditText = view.findViewById<EditText>(R.id.location_edit_text)

        // If we are editing a job, pre-fill the input fields
        if (jobToEdit != null) {
            titleEditText.setText(jobToEdit.title)
            descriptionEditText.setText(jobToEdit.description)
            budgetEditText.setText(jobToEdit.budget.toString())
            contactNumberEditText.setText(jobToEdit.contactNumber)
            locationEditText.setText(jobToEdit.location)
        }

        val builder = AlertDialog.Builder(this)
        builder.setView(view)
        builder.setTitle(if (jobToEdit == null) getString(R.string.add_job) else getString(R.string.edit_job))
        builder.setPositiveButton(if (jobToEdit == null) getString(R.string.add) else getString(R.string.update)) { dialog, _ ->
            val job = Book(
                id = jobToEdit?.id ?: "",
                title = titleEditText.text.toString(),
                description = descriptionEditText.text.toString(),
                budget = budgetEditText.text.toString().toDoubleOrNull() ?: 0.0,
                contactNumber = contactNumberEditText.text.toString(),
                location = locationEditText.text.toString()
            )

            if (jobToEdit == null) {
                viewModel.addJob(job)
            } else {
                viewModel.updateJob(job)
            }

            // Clear the input fields
            titleEditText.text.clear()
            descriptionEditText.text.clear()
            budgetEditText.text.clear()
            contactNumberEditText.text.clear()
            locationEditText.text.clear()

            dialog.dismiss()
        }
        builder.setNegativeButton(getString(R.string.cancel)) { dialog, _ ->
            dialog.dismiss()
        }

        val alertDialog = builder.create()
        alertDialog.show()
    }
}