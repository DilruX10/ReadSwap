package com.example.ReadSwap

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class JobAdapter(
    private val onEditClick: (Book) -> Unit,
    private val onDeleteClick: (Book) -> Unit,
    private val onPayClick: (Book) -> Unit,
    private val showPaymentButton: Boolean
) : RecyclerView.Adapter<JobAdapter.JobViewHolder>() {

    private var books: List<Book> = listOf()

    fun setJobs(books: List<Book>) {
        this.books = books
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.job_item, parent, false)
        return JobViewHolder(view)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        val book = books[position]
        holder.bind(book, showPaymentButton)

        holder.editButton.setOnClickListener {
            onEditClick(book)
        }

        holder.deleteButton.setOnClickListener {
            onDeleteClick(book)
        }

        if (showPaymentButton) {
            holder.paymentButton.setOnClickListener {
                onPayClick(book)
            }
        }
    }

    override fun getItemCount(): Int {
        return books.size
    }

    inner class JobViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.job_title)
        private val descriptionTextView: TextView = itemView.findViewById(R.id.job_description)
        private val budgetTextView: TextView = itemView.findViewById(R.id.job_budget)
        private val contactNumberTextView: TextView = itemView.findViewById(R.id.job_contact_number)
        private val locationTextView: TextView = itemView.findViewById(R.id.job_location)
        val editButton: ImageButton = itemView.findViewById(R.id.edit_button)
        val deleteButton: ImageButton = itemView.findViewById(R.id.delete_button)
        val paymentButton: Button = itemView.findViewById(R.id.payment_button)

        fun bind(book: Book, showPaymentButton: Boolean) {
            titleTextView.text = book.title
            descriptionTextView.text = book.description
            budgetTextView.text = itemView.context.getString(R.string.budget_format, book.budget)
            contactNumberTextView.text = book.contactNumber
            locationTextView.text = book.location

            paymentButton.visibility = if (showPaymentButton) View.VISIBLE else View.GONE
        }
    }
}
